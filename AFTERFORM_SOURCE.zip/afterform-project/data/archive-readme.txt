Clothes1 Organized — پوشه‌بندی و نام‌گذاری مجموعه تصاویر

تعداد کل تصاویر: 84 فایل JPG

ساختار پوشه‌ها:
- 01_Bags/01_Messenger_And_Crossbody_Bags: 13 تصویر
- 01_Bags/02_Briefcases_And_Work_Bags: 4 تصویر
- 01_Bags/03_Shoulder_And_Hobo_Bags: 3 تصویر
- 02_Shoes/01_Boots_And_Hiking_Boots: 4 تصویر
- 02_Shoes/02_Sneakers_And_Canvas_Shoes: 7 تصویر
- 02_Shoes/03_Leather_Casual_And_Dress_Shoes: 4 تصویر
- 03_Watches: 7 تصویر
- 04_Outerwear/01_Leather_And_Suede_Jackets: 5 تصویر
- 04_Outerwear/02_Bomber_And_Casual_Jackets: 7 تصویر
- 04_Outerwear/03_Field_And_Utility_Jackets: 2 تصویر
- 04_Outerwear/04_Coats_And_Overcoats: 2 تصویر
- 05_Tops/01_Sweaters_And_Knitwear: 8 تصویر
- 05_Tops/02_Shirts_And_Polos: 3 تصویر
- 05_Tops/03_T_Shirts_And_Long_Sleeve_Tops: 7 تصویر
- 05_Tops/04_Hoodies_And_Sweatshirts: 2 تصویر
- 05_Tops/05_Henley_Tops: 1 تصویر
- 06_Bottoms/01_Trousers_And_Sweatpants: 2 تصویر
- 06_Bottoms/02_Shorts_And_Denim_Shorts: 1 تصویر
- 07_Accessories/01_Gloves: 1 تصویر
- 07_Accessories/02_Hats_And_Caps: 1 تصویر

نکات:
- نام هر فایل با شماره سه‌رقمی و شرح انگلیسی نوع/رنگ کالا تنظیم شده است.
- فایل File_Index.csv نام اصلی هر تصویر را به مسیر جدید و توضیح فارسی آن وصل می‌کند.
- هیچ تصویری حذف نشده است.
- دو فایل تکراری دقیق در ردیف‌های 024 و 025 نگه داشته شده‌اند؛ نسخه دوم با پسوند Duplicate مشخص شده است.
- مواردی که جنس یا مدل دقیقشان از عکس قابل تشخیص نبوده، با عنوان عمومی‌تر نام‌گذاری شده‌اند.
