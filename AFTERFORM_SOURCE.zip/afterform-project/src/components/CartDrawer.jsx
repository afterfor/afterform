import { ArrowLeft, Minus, Plus, ShoppingBag, Trash2, X } from 'lucide-react'
import { useStore } from '../context/StoreContext'
import { asset, formatPrice, navigate } from '../utils/format'

export default function CartDrawer() {
  const { cartItems, cartOpen, setCartOpen, updateQuantity, removeFromCart, subtotal, shipping, total, count } = useStore()
  return (
    <>
      <button className={`drawer-scrim ${cartOpen ? 'scrim-visible' : ''}`} onClick={() => setCartOpen(false)} aria-label="بستن سبد" tabIndex={cartOpen ? 0 : -1} />
      <aside className={`cart-drawer ${cartOpen ? 'cart-drawer-open' : ''}`} aria-hidden={!cartOpen} aria-label="سبد خرید">
        <div className="drawer-header"><div><span className="eyebrow">AFTERFORM / BAG</span><h2>سبد خرید <sup>{String(count).padStart(2, '0')}</sup></h2></div><button className="icon-button" onClick={() => setCartOpen(false)} aria-label="بستن"><X /></button></div>
        {cartItems.length === 0 ? (
          <div className="drawer-empty"><div className="empty-symbol"><ShoppingBag size={30} /></div><h3>سبد هنوز خالی است.</h3><p>یک فرم تازه انتخاب کن و این‌جا برگرد.</p><button className="button button-dark" onClick={() => { setCartOpen(false); navigate('/shop') }}>رفتن به فروشگاه <ArrowLeft size={16} /></button></div>
        ) : (
          <>
            <div className="drawer-items">{cartItems.map((item) => <div className="drawer-item" key={`${item.productId}-${item.size}-${item.color.id}`}>
              <a href={`#/product/${item.product.id}`} className="drawer-item-image" onClick={() => setCartOpen(false)}><img src={asset(item.product.image)} alt={item.product.alt} /></a>
              <div className="drawer-item-info"><a href={`#/product/${item.product.id}`} onClick={() => setCartOpen(false)}>{item.product.name.split(' · ')[0]}</a><small>{item.size} / {item.color.label}</small><strong>{formatPrice(item.product.price * item.quantity)}</strong>
                <div className="drawer-item-bottom"><div className="quantity-control quantity-small"><button onClick={() => updateQuantity(item.productId, item.size, item.color.id, item.quantity - 1)} aria-label="کاهش تعداد"><Minus size={13} /></button><span>{item.quantity}</span><button onClick={() => updateQuantity(item.productId, item.size, item.color.id, item.quantity + 1)} aria-label="افزایش تعداد"><Plus size={13} /></button></div><button className="remove-item" onClick={() => removeFromCart(item.productId, item.size, item.color.id)} aria-label="حذف محصول"><Trash2 size={15} /></button></div>
              </div>
            </div>)}</div>
            <div className="drawer-summary"><div><span>جمع جزء</span><strong>{formatPrice(subtotal)}</strong></div><div><span>ارسال</span><strong>{shipping ? formatPrice(shipping) : 'رایگان'}</strong></div><div className="drawer-total"><span>مبلغ نهایی</span><strong>{formatPrice(total)}</strong></div><button className="button button-blue button-full" onClick={() => { setCartOpen(false); navigate('/checkout') }}>ادامه و ثبت سفارش <ArrowLeft size={17} /></button><button className="continue-link" onClick={() => setCartOpen(false)}>ادامه خرید</button></div>
          </>
        )}
        <span className="drawer-vertical">MOVE IN YOUR OWN FORM</span>
      </aside>
    </>
  )
}
