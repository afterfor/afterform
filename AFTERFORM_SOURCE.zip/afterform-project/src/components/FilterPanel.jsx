import { RotateCcw } from 'lucide-react'

const categories = [
  ['bags', 'کیف'], ['shoes', 'کفش'], ['watches', 'ساعت'], ['outerwear', 'لباس بیرونی'], ['tops', 'بالاپوش'], ['bottoms', 'پایین‌پوش'], ['accessories', 'اکسسوری']
]
const colors = [
  ['black','مشکی','#24262b'],['brown','قهوه‌ای','#805b43'],['navy','سرمه‌ای','#25365d'],['blue','آبی','#416dba'],['olive','زیتونی','#65714a'],['green','سبز','#496a50'],['grey','طوسی','#9299a4'],['charcoal','ذغالی','#4b505b'],['burgundy','زرشکی','#712f44'],['red','قرمز','#bc4549'],['purple','بنفش','#6f547d'],['khaki','خاکی','#a59a78'],['beige','بژ','#c3b69b'],['mustard','خردلی','#b18a32'],['gold','طلایی','#b69a54'],['silver','نقره‌ای','#9ea5ad'],['rose','صورتی','#c78a9c'],['other','ترکیبی','#8d96a5']
]
const sizes = ['S','M','L','XL','۴۰','۴۱','۴۲','۴۳','۴۴','تک‌سایز']

export default function FilterPanel({ filters, setFilters, onClear, mobile = false }) {
  const set = (key, value) => setFilters((current) => ({ ...current, [key]: value }))
  return (
    <div className={`filter-panel ${mobile ? 'filter-panel-mobile' : ''}`}>
      <div className="filter-heading"><span>فیلترها <small>FILTER / 01</small></span><button onClick={onClear}><RotateCcw size={14} /> پاک‌کردن</button></div>
      <div className="filter-section"><span className="filter-label">دسته‌بندی <i>01</i></span>
        {categories.map(([id, label]) => <label className="filter-check" key={id}><input type="checkbox" checked={filters.categories.includes(id)} onChange={(event) => set('categories', event.target.checked ? [...filters.categories, id] : filters.categories.filter((item) => item !== id))} /><span>{label}</span><b /></label>)}
      </div>
      <div className="filter-section"><span className="filter-label">رنگ <i>02</i></span><div className="color-filter-grid">{colors.map(([id, label, hex]) => <button type="button" key={id} title={label} aria-label={label} className={`color-filter ${filters.colors.includes(id) ? 'color-filter-active' : ''}`} onClick={() => set('colors', filters.colors.includes(id) ? filters.colors.filter((item) => item !== id) : [...filters.colors, id])}><i style={{ background: hex }} />{filters.colors.includes(id) && <span>{label}</span>}</button>)}</div></div>
      <div className="filter-section"><span className="filter-label">سایز <i>03</i></span><div className="filter-size-grid">{sizes.map((size) => <button type="button" key={size} className={filters.sizes.includes(size) ? 'filter-size-active' : ''} onClick={() => set('sizes', filters.sizes.includes(size) ? filters.sizes.filter((item) => item !== size) : [...filters.sizes, size])}>{size}</button>)}</div></div>
      <div className="filter-section"><span className="filter-label">بازه قیمت <i>04</i></span><div className="price-range-label"><span>{new Intl.NumberFormat('fa-IR').format(filters.minPrice)}</span><span>{new Intl.NumberFormat('fa-IR').format(filters.maxPrice)}</span></div><input className="range-input" aria-label="حداقل قیمت" type="range" min="0" max="7000000" step="100000" value={filters.minPrice} onChange={(event) => set('minPrice', Math.min(Number(event.target.value), filters.maxPrice))} /><input className="range-input range-reverse" aria-label="حداکثر قیمت" type="range" min="0" max="7000000" step="100000" value={filters.maxPrice} onChange={(event) => set('maxPrice', Math.max(Number(event.target.value), filters.minPrice))} /></div>
      <div className="filter-section filter-availability"><label className="switch-row"><span>فقط کالاهای موجود</span><input type="checkbox" checked={filters.availableOnly} onChange={(event) => set('availableOnly', event.target.checked)} /><i /></label></div>
    </div>
  )
}
