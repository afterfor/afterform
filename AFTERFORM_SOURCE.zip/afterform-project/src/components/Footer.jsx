import { ArrowUpLeft, Instagram, MoveUpRight } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="site-footer">
      <div className="footer-main">
        <div className="footer-brand">
          <a href="#/" className="footer-wordmark">AFTERFORM<span>®</span></a>
          <p>فرم، یک انتخاب ثابت نیست.<br />هر روز دوباره ساخته می‌شود.</p>
          <span className="footer-stamp">INDEPENDENT FORM STUDY / 2026</span>
        </div>
        <div className="footer-column"><span className="footer-label">کاوش</span><a href="#/shop">همه محصولات</a><a href="#/shop?category=outerwear">لباس بیرونی</a><a href="#/shop?category=tops">بالاپوش</a><a href="#/shop?category=shoes">کفش</a></div>
        <div className="footer-column"><span className="footer-label">راهنما</span><a href="#/checkout">ثبت سفارش آزمایشی</a><a href="#/shop?favorites=1">علاقه‌مندی‌ها</a><a href="#/cart">سبد خرید</a><a href="mailto:hello@afterform.example">ارتباط با ما</a></div>
        <div className="footer-social"><span className="footer-label">در مدار AFTERFORM</span><a href="https://instagram.com" target="_blank" rel="noreferrer">اینستاگرام <Instagram size={16} /></a><span>hello@afterform.example</span></div>
      </div>
      <div className="footer-bottom"><span>© AFTERFORM 2026 — همه حقوق محفوظ است.</span><span>یک فروشگاه نمایشی؛ سفارش‌ها پردازش واقعی نمی‌شوند.</span><a href="#/" aria-label="بازگشت به بالا">بازگشت به بالا <MoveUpRight size={14} /></a></div>
      <div className="footer-outline">AFTERFORM</div>
    </footer>
  )
}
