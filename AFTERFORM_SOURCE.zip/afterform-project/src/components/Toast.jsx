import { useEffect } from 'react'
import { Check, AlertCircle, X } from 'lucide-react'

export default function Toast({ toast, dismiss }) {
  useEffect(() => {
    if (!toast) return undefined
    const timer = window.setTimeout(dismiss, 3100)
    return () => window.clearTimeout(timer)
  }, [toast, dismiss])

  if (!toast) return null
  const Icon = toast.type === 'error' ? AlertCircle : Check
  return (
    <div className={`toast ${toast.type === 'error' ? 'toast-error' : ''}`} role="status" key={toast.key}>
      <span className="toast-icon"><Icon size={17} /></span>
      <span>{toast.message}</span>
      <button className="toast-close" onClick={dismiss} aria-label="بستن پیام"><X size={15} /></button>
    </div>
  )
}
