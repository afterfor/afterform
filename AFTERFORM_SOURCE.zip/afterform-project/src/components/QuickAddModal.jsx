import { useEffect, useState } from 'react'
import { X, ShoppingBag } from 'lucide-react'
import { useStore } from '../context/StoreContext'
import { asset, formatPrice } from '../utils/format'

export default function QuickAddModal() {
  const { quickProduct, setQuickProduct, addToCart } = useStore()
  const [size, setSize] = useState('')
  useEffect(() => {
    setSize(quickProduct?.sizes?.[0] || '')
  }, [quickProduct])
  useEffect(() => {
    if (!quickProduct) return undefined
    const close = (event) => event.key === 'Escape' && setQuickProduct(null)
    window.addEventListener('keydown', close)
    return () => window.removeEventListener('keydown', close)
  }, [quickProduct, setQuickProduct])
  if (!quickProduct) return null
  return (
    <div className="modal-layer" role="presentation" onMouseDown={(event) => event.target === event.currentTarget && setQuickProduct(null)}>
      <section className="quick-modal" role="dialog" aria-modal="true" aria-labelledby="quick-title">
        <button className="modal-close icon-button" onClick={() => setQuickProduct(null)} aria-label="بستن"><X /></button>
        <div className="quick-modal-image"><img src={asset(quickProduct.image)} alt={quickProduct.alt} /></div>
        <div className="quick-modal-content"><span className="eyebrow">QUICK SELECT / {quickProduct.model}</span><h2 id="quick-title">{quickProduct.name.split(' · ')[0]}</h2><strong>{formatPrice(quickProduct.price)}</strong>
          <span className="field-caption">انتخاب سایز</span>
          <div className="size-options">{quickProduct.sizes.map((value) => <button key={value} onClick={() => setSize(value)} className={size === value ? 'size-selected' : ''}>{value}</button>)}</div>
          <button className="button button-dark button-full" onClick={() => addToCart(quickProduct, size)} disabled={quickProduct.stock < 1}><ShoppingBag size={18} /> افزودن به سبد</button>
          <span className="quick-note">انتخاب رنگ: {quickProduct.color.label} / موجودی: {quickProduct.stock || 0}</span>
        </div>
      </section>
    </div>
  )
}
