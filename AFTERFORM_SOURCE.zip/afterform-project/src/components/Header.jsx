import { useState } from 'react'
import { ArrowUpLeft, Menu, Search, ShoppingBag, X } from 'lucide-react'
import { useStore } from '../context/StoreContext'

const links = [
  { label: 'فروشگاه', path: '/shop' },
  { label: 'لباس بیرونی', path: '/shop?category=outerwear' },
  { label: 'بالاپوش', path: '/shop?category=tops' },
  { label: 'اکسسوری', path: '/shop?category=accessories' }
]

export default function Header({ route }) {
  const { count, setCartOpen } = useStore()
  const [mobileOpen, setMobileOpen] = useState(false)
  const [searchOpen, setSearchOpen] = useState(false)
  const [search, setSearch] = useState('')
  const submitSearch = (event) => {
    event.preventDefault()
    window.location.hash = `/shop?search=${encodeURIComponent(search.trim())}`
    setSearchOpen(false)
    setMobileOpen(false)
  }

  return (
    <>
      <div className="announcement"><span>DROP 01 <i /> انتخاب‌های تازه برای روزهای معمولی</span><span className="announcement-right">ارسال رایگان برای سفارش‌های بالای ۵ میلیون تومان <ArrowUpLeft size={13} /></span></div>
      <header className="site-header">
        <button className="mobile-menu-trigger icon-button" onClick={() => setMobileOpen(true)} aria-label="باز کردن منو"><Menu size={21} /></button>
        <a className="wordmark" href="#/" aria-label="صفحه اصلی AFTERFORM"><span>AFTER</span><span className="wordmark-shape">F</span><span>ORM</span><i>®</i></a>
        <nav className="desktop-nav" aria-label="ناوبری اصلی">
          {links.map((link) => <a key={link.path} className={route.pathname === '/shop' && (link.path === '/shop' || route.params.get('category') === link.path.split('=')[1]) ? 'nav-active' : ''} href={`#${link.path}`}>{link.label}</a>)}
        </nav>
        <div className="header-actions">
          <button className={`icon-button search-trigger ${searchOpen ? 'is-active' : ''}`} onClick={() => setSearchOpen((value) => !value)} aria-label="جست‌وجو"><Search size={19} /></button>
          <a className="saved-link" href="#/shop?favorites=1">علاقه‌مندی‌ها</a>
          <button className="cart-trigger" onClick={() => setCartOpen(true)} aria-label={`سبد خرید، ${count} کالا`}><ShoppingBag size={18} /><span>سبد</span><b>{String(count).padStart(2, '0')}</b></button>
        </div>
      </header>
      {searchOpen && <form className="search-bar" onSubmit={submitSearch}><Search size={19} /><input autoFocus value={search} onChange={(event) => setSearch(event.target.value)} placeholder="دنبال چه چیزی هستی؟" aria-label="جست‌وجوی محصولات" /><button type="submit">جست‌وجو <ArrowUpLeft size={16} /></button><button type="button" className="icon-button" onClick={() => setSearchOpen(false)} aria-label="بستن جست‌وجو"><X size={18} /></button></form>}
      <div className={`mobile-menu ${mobileOpen ? 'mobile-menu-open' : ''}`} aria-hidden={!mobileOpen}>
        <div className="mobile-menu-top"><span className="wordmark wordmark-small"><span>AFTER</span><span className="wordmark-shape">F</span><span>ORM</span></span><button className="icon-button" onClick={() => setMobileOpen(false)} aria-label="بستن منو"><X /></button></div>
        <div className="mobile-menu-links">{links.map((link, index) => <a key={link.path} href={`#${link.path}`} onClick={() => setMobileOpen(false)}><small>0{index + 1}</small>{link.label}<ArrowUpLeft /></a>)}</div>
        <a className="mobile-saved-link" href="#/shop?favorites=1" onClick={() => setMobileOpen(false)}>علاقه‌مندی‌ها</a>
        <div className="mobile-menu-bottom">MOVE IN YOUR OWN FORM</div>
      </div>
      {mobileOpen && <button className="menu-scrim" onClick={() => setMobileOpen(false)} aria-label="بستن منو" />}
    </>
  )
}
