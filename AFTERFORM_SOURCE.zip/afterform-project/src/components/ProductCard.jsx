import { ArrowUpLeft, Heart, Plus } from 'lucide-react'
import { useStore } from '../context/StoreContext'
import { asset, formatPrice, navigate } from '../utils/format'

export default function ProductCard({ product, variant = '' }) {
  const { favorites, toggleFavorite, setQuickProduct } = useStore()
  const favorite = favorites.includes(product.id)
  return (
    <article className={`product-card ${variant}`}>
      <div className="product-visual">
        <a href={`#/product/${product.id}`} className="product-image-link" aria-label={`دیدن ${product.name}`}>
          <img src={asset(product.image)} alt={product.alt} loading="lazy" />
        </a>
        <span className="product-index">{product.model}</span>
        <button className={`favorite-button ${favorite ? 'favorite-active' : ''}`} onClick={() => toggleFavorite(product.id)} aria-label={favorite ? 'حذف از علاقه‌مندی‌ها' : 'افزودن به علاقه‌مندی‌ها'}><Heart size={17} fill={favorite ? 'currentColor' : 'none'} /></button>
        <button className="quick-add-button" onClick={() => setQuickProduct(product)} disabled={product.stock < 1} aria-label="افزودن سریع به سبد"><Plus size={18} /><span>افزودن سریع</span></button>
        {product.stock < 1 && <span className="sold-out-tag">ناموجود</span>}
      </div>
      <div className="product-meta">
        <div className="product-meta-top"><span>{product.categoryLabel} / {product.subcategory}</span><i style={{ background: product.color.hex }} title={product.color.label} /></div>
        <a className="product-name" href={`#/product/${product.id}`}>{product.name.split(' · ')[0]}</a>
        <div className="product-price-row"><strong>{formatPrice(product.price)}</strong><a href={`#/product/${product.id}`} aria-label="مشاهده محصول"><ArrowUpLeft size={16} /></a></div>
      </div>
    </article>
  )
}
