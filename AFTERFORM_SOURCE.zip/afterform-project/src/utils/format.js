export const formatPrice = (amount) => `${new Intl.NumberFormat('fa-IR').format(amount)} تومان`

export const asset = (path) => `${import.meta.env.BASE_URL}${path.replace(/^\//, '')}`

export const navigate = (path) => {
  window.location.hash = path.startsWith('/') ? path : `/${path}`
  window.scrollTo({ top: 0, behavior: 'auto' })
}

export const getRoute = () => {
  const raw = window.location.hash.slice(1) || '/'
  const [pathname, query = ''] = raw.split('?')
  return { pathname: pathname || '/', params: new URLSearchParams(query) }
}

export const sizeLabel = (size) => size === 'تک‌سایز' ? 'تک‌سایز' : size
