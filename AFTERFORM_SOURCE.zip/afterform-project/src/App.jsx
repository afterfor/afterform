import { useCallback, useEffect, useState } from 'react'
import { StoreProvider, useStore } from './context/StoreContext'
import Header from './components/Header'
import Footer from './components/Footer'
import CartDrawer from './components/CartDrawer'
import QuickAddModal from './components/QuickAddModal'
import Toast from './components/Toast'
import HomePage from './pages/HomePage'
import ShopPage from './pages/ShopPage'
import ProductPage from './pages/ProductPage'
import CartPage from './pages/CartPage'
import CheckoutPage from './pages/CheckoutPage'
import { getRoute } from './utils/format'

function AppContent() {
  const [route, setRoute] = useState(getRoute)
  const { toast, setToast } = useStore()
  const dismissToast = useCallback(() => setToast(null), [setToast])

  useEffect(() => {
    const updateRoute = () => {
      setRoute(getRoute())
      window.scrollTo({ top: 0, behavior: 'auto' })
    }
    window.addEventListener('hashchange', updateRoute)
    return () => window.removeEventListener('hashchange', updateRoute)
  }, [])

  useEffect(() => {
    const revealNodes = document.querySelectorAll('.reveal-on-scroll')
    if (!('IntersectionObserver' in window)) {
      revealNodes.forEach((node) => node.classList.add('reveal-visible'))
      return undefined
    }
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('reveal-visible')
          observer.unobserve(entry.target)
        }
      })
    }, { threshold: 0.12 })
    revealNodes.forEach((node) => observer.observe(node))
    return () => observer.disconnect()
  }, [route.pathname])

  const path = route.pathname.replace(/\/+$/, '') || '/'
  let page
  if (path === '/') page = <HomePage />
  else if (path === '/shop') page = <ShopPage params={route.params} />
  else if (path.startsWith('/product/')) page = <ProductPage id={path.split('/')[2]} />
  else if (path === '/cart') page = <CartPage />
  else if (path === '/checkout') page = <CheckoutPage />
  else page = <main className="not-found"><span>AF / 404</span><h1>این مسیر در آرشیو نیست.</h1><a href="#/">بازگشت به خانه</a></main>

  return <>
    <Header route={route} />
    {page}
    <Footer />
    <CartDrawer />
    <QuickAddModal />
    <Toast toast={toast} dismiss={dismissToast} />
  </>
}

export default function App() {
  return <StoreProvider><AppContent /></StoreProvider>
}
