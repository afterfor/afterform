import { createContext, useContext, useEffect, useMemo, useState } from 'react'
import products from '../data/products.json'

const StoreContext = createContext(null)

export function StoreProvider({ children }) {
  const [cart, setCart] = useState(() => JSON.parse(localStorage.getItem('afterform-cart') || '[]'))
  const [favorites, setFavorites] = useState(() => JSON.parse(localStorage.getItem('afterform-favorites') || '[]'))
  const [cartOpen, setCartOpen] = useState(false)
  const [quickProduct, setQuickProduct] = useState(null)
  const [toast, setToast] = useState(null)

  useEffect(() => localStorage.setItem('afterform-cart', JSON.stringify(cart)), [cart])
  useEffect(() => localStorage.setItem('afterform-favorites', JSON.stringify(favorites)), [favorites])

  const notify = (message, type = 'success') => {
    setToast({ message, type, key: Date.now() })
  }

  const addToCart = (product, size, color = product.color, quantity = 1) => {
    if (!product || product.stock < 1) {
      notify('این محصول در حال حاضر موجود نیست.', 'error')
      return false
    }
    const existing = cart.find((item) => item.productId === product.id && item.size === size && item.color.id === color.id)
    if (existing && existing.quantity + quantity > product.stock) {
      notify('بیشتر از موجودی فعلی نمی‌توان اضافه کرد.', 'error')
      return false
    }
    setCart((current) => {
      const keyMatch = current.find((item) => item.productId === product.id && item.size === size && item.color.id === color.id)
      if (keyMatch) return current.map((item) => item === keyMatch ? { ...item, quantity: Math.min(item.quantity + quantity, product.stock) } : item)
      return [...current, { productId: product.id, size, color, quantity: Math.min(quantity, product.stock) }]
    })
    notify('به سبد اضافه شد.')
    setQuickProduct(null)
    setCartOpen(true)
    return true
  }

  const updateQuantity = (productId, size, colorId, quantity) => {
    const product = products.find((item) => item.id === productId)
    if (quantity < 1) {
      setCart((current) => current.filter((item) => !(item.productId === productId && item.size === size && item.color.id === colorId)))
      return
    }
    const safeQuantity = Math.min(quantity, product?.stock || 1)
    setCart((current) => current.map((item) => item.productId === productId && item.size === size && item.color.id === colorId ? { ...item, quantity: safeQuantity } : item))
  }

  const removeFromCart = (productId, size, colorId) => {
    setCart((current) => current.filter((item) => !(item.productId === productId && item.size === size && item.color.id === colorId)))
    notify('محصول از سبد حذف شد.')
  }

  const clearCart = () => setCart([])

  const toggleFavorite = (id) => {
    setFavorites((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id])
  }

  const cartItems = useMemo(() => cart.map((item) => {
    const product = products.find((entry) => entry.id === item.productId)
    return product ? { ...item, product } : null
  }).filter(Boolean), [cart])

  const subtotal = cartItems.reduce((total, item) => total + item.product.price * item.quantity, 0)
  const shipping = subtotal === 0 || subtotal >= 5000000 ? 0 : 85000
  const total = subtotal + shipping
  const count = cartItems.reduce((sum, item) => sum + item.quantity, 0)

  const value = {
    products, cart, cartItems, favorites, cartOpen, setCartOpen, quickProduct, setQuickProduct,
    toast, setToast, notify, addToCart, updateQuantity, removeFromCart, toggleFavorite, clearCart,
    subtotal, shipping, total, count
  }

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>
}

export const useStore = () => useContext(StoreContext)
