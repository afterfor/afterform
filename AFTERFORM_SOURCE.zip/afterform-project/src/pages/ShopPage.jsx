import { useEffect, useMemo, useState } from 'react'
import { ArrowDownUp, ArrowUpLeft, Filter, Search, X } from 'lucide-react'
import ProductCard from '../components/ProductCard'
import FilterPanel from '../components/FilterPanel'
import { useStore } from '../context/StoreContext'

const emptyFilters = { categories: [], colors: [], sizes: [], minPrice: 0, maxPrice: 7000000, availableOnly: false }
const sortOptions = [
  ['newest','تازه‌ترین'],['price-low','ارزان‌ترین'],['price-high','گران‌ترین'],['name','نام محصول']
]

export default function ShopPage({ params }) {
  const { products, favorites } = useStore()
  const [filters, setFilters] = useState(() => ({ ...emptyFilters, categories: params.get('category') ? [params.get('category')] : [] }))
  const [search, setSearch] = useState(params.get('search') || '')
  const [sort, setSort] = useState('newest')
  const [mobileFilters, setMobileFilters] = useState(false)
  useEffect(() => {
    setFilters({ ...emptyFilters, categories: params.get('category') ? [params.get('category')] : [] })
    setSearch(params.get('search') || '')
  }, [params.toString()])
  const favoriteOnly = params.get('favorites') === '1'

  const filtered = useMemo(() => {
    const term = search.trim().toLocaleLowerCase('fa-IR')
    let result = products.filter((product) => {
      if (favoriteOnly && !favorites.includes(product.id)) return false
      if (filters.categories.length && !filters.categories.includes(product.category)) return false
      if (filters.colors.length && !filters.colors.includes(product.color.id)) return false
      if (filters.sizes.length && !filters.sizes.some((size) => product.sizes.includes(size))) return false
      if (product.price < filters.minPrice || product.price > filters.maxPrice) return false
      if (filters.availableOnly && product.stock < 1) return false
      if (term && !`${product.name} ${product.description} ${product.categoryLabel} ${product.subcategory} ${product.model}`.toLocaleLowerCase('fa-IR').includes(term)) return false
      return true
    })
    if (sort === 'price-low') result = [...result].sort((a,b) => a.price - b.price)
    else if (sort === 'price-high') result = [...result].sort((a,b) => b.price - a.price)
    else if (sort === 'name') result = [...result].sort((a,b) => a.name.localeCompare(b.name, 'fa'))
    else result = [...result].sort((a,b) => b.created - a.created)
    return result
  }, [products, favorites, filters, search, sort, favoriteOnly])

  const clearFilters = () => { setFilters(emptyFilters); setSearch('') }
  const activeCount = filters.categories.length + filters.colors.length + filters.sizes.length + Number(filters.minPrice > 0 || filters.maxPrice < 7000000) + Number(filters.availableOnly)

  return (
    <main className="shop-page">
      <div className="shop-masthead"><div><span className="eyebrow">AFTERFORM / THE STORE</span><h1>{favoriteOnly ? 'نشان‌شده‌ها' : 'همهٔ فرم‌ها'}<span>.</span></h1><p>قطعه‌های آرشیو؛ انتخاب برای زندگیِ در حرکت.</p></div><div className="shop-masthead-mark"><span>CATALOGUE</span><strong>83</strong><i>UNIQUE OBJECTS / DROP 01</i></div></div>
      <div className="shop-toolbar"><div className="shop-result-count"><span>{new Intl.NumberFormat('fa-IR').format(filtered.length)}</span> نتیجه <i>/</i> {new Intl.NumberFormat('fa-IR').format(products.length)} محصول</div><div className="shop-toolbar-controls"><form className="shop-search" onSubmit={(event) => event.preventDefault()}><Search size={16} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="جست‌وجو در فرم‌ها" aria-label="جست‌وجو در کاتالوگ" />{search && <button type="button" onClick={() => setSearch('')} aria-label="پاک کردن جست‌وجو"><X size={14} /></button>}</form><label className="sort-select"><ArrowDownUp size={15} /><select value={sort} onChange={(event) => setSort(event.target.value)} aria-label="مرتب‌سازی">{sortOptions.map(([value,label]) => <option key={value} value={value}>{label}</option>)}</select></label><button className="mobile-filter-trigger" onClick={() => setMobileFilters(true)}><Filter size={16} /> فیلترها {activeCount > 0 && <b>{activeCount}</b>}</button></div></div>
      <div className="shop-layout"><aside className="desktop-filter"><FilterPanel filters={filters} setFilters={setFilters} onClear={clearFilters} /></aside><section className="shop-products" aria-label="فهرست محصولات"><div className="shop-grid">{filtered.map((product, index) => <ProductCard key={product.id} product={product} variant={index % 5 === 2 ? 'product-card-tall' : ''} />)}</div>{filtered.length === 0 && <div className="no-results"><span>AF / 404</span><h2>چیزی پیدا نشد.</h2><p>عبارت جست‌وجو یا فیلترها را تغییر بده.</p><button className="button button-dark" onClick={clearFilters}>پاک‌کردن فیلترها <ArrowUpLeft size={16} /></button></div>}</section></div>
      {mobileFilters && <div className="mobile-filter-overlay"><button className="mobile-filter-backdrop" onClick={() => setMobileFilters(false)} aria-label="بستن فیلتر" /><section className="mobile-filter-sheet"><div className="mobile-sheet-head"><div><span className="eyebrow">FILTER / REFINE</span><h2>فیلتر محصولات</h2></div><button className="icon-button" onClick={() => setMobileFilters(false)} aria-label="بستن"><X /></button></div><FilterPanel filters={filters} setFilters={setFilters} onClear={clearFilters} mobile /><button className="button button-blue button-full" onClick={() => setMobileFilters(false)}>نمایش {new Intl.NumberFormat('fa-IR').format(filtered.length)} محصول <ArrowUpLeft size={17} /></button></section></div>}
    </main>
  )
}
