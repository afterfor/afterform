import { useEffect, useMemo, useState } from 'react'
import { ArrowUpLeft, Check, Minus, Plus, Ruler, ShoppingBag, Truck } from 'lucide-react'
import ProductCard from '../components/ProductCard'
import { useStore } from '../context/StoreContext'
import { asset, formatPrice } from '../utils/format'

export default function ProductPage({ id }) {
  const { products, addToCart } = useStore()
  const product = products.find((item) => item.id === id)
  const [size, setSize] = useState(product?.sizes?.[0] || '')
  const [quantity, setQuantity] = useState(1)
  useEffect(() => { setSize(product?.sizes?.[0] || ''); setQuantity(1) }, [id])
  const [sizeGuideOpen, setSizeGuideOpen] = useState(false)
  const related = useMemo(() => product ? products.filter((item) => item.category === product.category && item.id !== product.id).slice(0, 3) : [], [products, product])

  if (!product) return <main className="not-found"><span>AF / 404</span><h1>این فرم پیدا نشد.</h1><a href="#/shop">بازگشت به فروشگاه <ArrowUpLeft /></a></main>

  return (
    <main className="product-page">
      <div className="breadcrumbs"><a href="#/">خانه</a><span>/</span><a href={`#/shop?category=${product.category}`}>{product.categoryLabel}</a><span>/</span><b>{product.model}</b></div>
      <div className="product-detail-layout">
        <div className="detail-gallery"><div className="detail-image"><img src={asset(product.image)} alt={product.alt} fetchPriority="high" /><span className="detail-image-code">{product.model} / ORIGINAL ARCHIVE</span><span className="detail-image-axis">AFTERFORM®</span></div><div className="detail-gallery-caption"><span>ARCHIVE IMAGE / 01</span><span>نمای محصول بر اساس تصویر موجود در آرشیو</span></div></div>
        <div className="product-info-panel"><div className="detail-topline"><span className="eyebrow">{product.categoryLabel} / {product.subcategory}</span><span className="stock-status"><i className={product.stock > 0 ? '' : 'stock-out'} />{product.stock > 0 ? 'موجود در آرشیو' : 'ناموجود'}</span></div>
          <span className="detail-model">{product.model} — DROP 01</span><h1>{product.name.split(' · ')[0]}</h1><strong className="detail-price">{formatPrice(product.price)}</strong><p className="detail-description">{product.description}. قطعه‌ای از مجموعهٔ AFTERFORM با تمرکز بر فرم، کارکرد و استفادهٔ روزمره.</p>{product.sourceNote && <p className="detail-source-note">یادداشت آرشیو: {product.sourceNote}</p>}
          <div className="detail-option"><div className="option-heading"><span>رنگ</span><b>{product.color.label}</b></div><button className="detail-color-swatch" aria-label={`رنگ ${product.color.label}`}><i style={{ background: product.color.hex }} />{product.color.label}<Check size={15} /></button></div>
          <div className="detail-option"><div className="option-heading"><span>انتخاب سایز</span><button className="size-guide-trigger" onClick={() => setSizeGuideOpen(true)}><Ruler size={15} /> راهنمای سایز</button></div><div className="detail-size-grid">{product.sizes.map((item) => <button key={item} onClick={() => setSize(item)} className={size === item ? 'detail-size-active' : ''}>{item}</button>)}</div></div>
          <div className="detail-buy-row"><div className="quantity-control"><button onClick={() => setQuantity((v) => Math.max(1, v - 1))} aria-label="کاهش تعداد"><Minus size={15} /></button><span>{new Intl.NumberFormat('fa-IR').format(quantity)}</span><button onClick={() => setQuantity((v) => Math.min(product.stock || 1, v + 1))} aria-label="افزایش تعداد"><Plus size={15} /></button></div><button className="button button-blue add-detail-button" disabled={product.stock < 1} onClick={() => addToCart(product, size, product.color, quantity)}><ShoppingBag size={18} /> افزودن به سبد</button></div>
          <div className="detail-availability"><span><Truck size={17} /> ارسال نمایشی از انبار AFTERFORM</span><span><Check size={16} /> {product.stock > 0 ? `موجودی: ${product.stock} عدد` : 'در حال حاضر موجود نیست'}</span></div>
          <div className="product-specs"><div><span>جنس</span><b>{product.fabric}</b></div><div><span>فرم / فیت</span><b>{product.fit}</b></div><div><span>گروه</span><b>{product.subcategory}</b></div><div><span>کد آرشیو</span><b>{product.model}</b></div></div>
          <p className="detail-disclaimer">اطلاعات جنس و رنگ بر پایهٔ نام‌گذاری و شواهد تصویری آرشیو است؛ جزئیات غیرقابل‌تشخیص به‌صورت قطعی اعلام نشده‌اند.</p>
        </div>
      </div>
      {related.length > 0 && <section className="related-section"><div className="section-heading"><div><span className="eyebrow">MORE FROM THIS CATEGORY</span><h2>فرم‌های <span>هم‌مسیر</span></h2></div><a className="text-link" href={`#/shop?category=${product.category}`}>دیدن همه <ArrowUpLeft size={16} /></a></div><div className="related-grid">{related.map((item) => <ProductCard key={item.id} product={item} />)}</div></section>}
      {sizeGuideOpen && <div className="modal-layer" onMouseDown={(event) => event.target === event.currentTarget && setSizeGuideOpen(false)}><section className="size-guide-modal" role="dialog" aria-modal="true"><div className="size-guide-head"><div><span className="eyebrow">FIT REFERENCE</span><h2>راهنمای انتخاب</h2></div><button className="icon-button" onClick={() => setSizeGuideOpen(false)} aria-label="بستن">×</button></div><p>این راهنما برای نمایش گروه سایزبندی همین کالا است؛ اندازه‌های دقیق در آرشیو تصویری ثبت نشده‌اند.</p><div className="size-guide-table"><div><b>سایز</b><b>توضیح</b></div>{product.sizes.map((item) => <div key={item}><b>{item}</b><span>{item === 'تک‌سایز' ? 'یک اندازه' : product.category === 'shoes' ? 'سایز کفش' : 'سایز پوشاک'}</span></div>)}</div><button className="button button-dark button-full" onClick={() => setSizeGuideOpen(false)}>متوجه شدم</button></section></div>}
    </main>
  )
}
