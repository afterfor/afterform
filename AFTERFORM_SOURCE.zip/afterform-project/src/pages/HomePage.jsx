import { useState } from 'react'
import { ArrowLeft, ArrowUpLeft, MoveDown, Send } from 'lucide-react'
import ProductCard from '../components/ProductCard'
import { useStore } from '../context/StoreContext'
import { asset } from '../utils/format'

const categoryInfo = [
  { id: 'outerwear', title: 'لباس بیرونی', sub: 'OUTER LAYERS' },
  { id: 'tops', title: 'بالاپوش', sub: 'DAILY TOPS' },
  { id: 'shoes', title: 'کفش', sub: 'ON THE MOVE' },
  { id: 'bags', title: 'کیف', sub: 'CARRY FORM' },
  { id: 'watches', title: 'ساعت', sub: 'TIME OBJECTS' },
  { id: 'bottoms', title: 'پایین‌پوش', sub: 'LOWER FORM' },
  { id: 'accessories', title: 'اکسسوری', sub: 'SMALL DETAILS' }
]

export default function HomePage() {
  const { products } = useStore()
  const [email, setEmail] = useState('')
  const [newsletterDone, setNewsletterDone] = useState(false)
  const hero = products.find((product) => product.id === 'af-013') || products[0]
  const arrivals = ['af-029', 'af-057', 'af-066', 'af-022'].map((id) => products.find((product) => product.id === id)).filter(Boolean)
  const campaign = products.find((product) => product.id === 'af-022') || products[9]
  const featured = products.find((product) => product.id === 'af-001') || products[0]
  const getCategoryProduct = (id) => products.find((product) => product.category === id)

  const submitNewsletter = (event) => {
    event.preventDefault()
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return
    setNewsletterDone(true)
  }

  return (
    <main className="home-page">
      <section className="home-hero">
        <div className="hero-backdrop-orb hero-orb-one" />
        <div className="hero-backdrop-orb hero-orb-two" />
        <div className="hero-copy">
          <div className="hero-kicker"><span className="live-dot" /> DROP 01 <i /> ARCHIVE OF MOVEMENT</div>
          <div className="hero-copy-main">
            <span className="hero-overline">لباس‌هایی برای ریتم خودت</span>
            <h1>هر روز،<br /><em>فرمِ خودت.</em></h1>
            <p>انتخاب‌هایی ساده، برای لحظه‌هایی که شبیه خودت‌اند.</p>
            <a className="hero-cta" href="#/shop"><span>دیدن مجموعه</span><b><ArrowUpLeft size={19} /></b></a>
          </div>
          <div className="hero-footnote"><span>EVERYDAY OBJECTS / 2026</span><span>01 — 07</span></div>
        </div>
        <div className="hero-art-wrap">
          <div className="hero-side-note"><span>01—26</span><span>THE FIRST DROP</span></div>
          <div className="hero-art">
            <div className="hero-art-halo" />
            <div className="hero-art-top"><span>AFTERFORM STUDIO</span><span>OBJECT / {hero.model?.replace('AF-', '') || '016'}</span></div>
            <a href={`#/product/${hero.id}`} className="hero-image-frame" aria-label={`مشاهده ${hero.name}`}>
              <img src={asset(hero.image)} alt={hero.alt} fetchPriority="high" />
            </a>
            <div className="hero-product-note"><span className="note-dot" /><div><small>SELECTED OBJECT</small><strong>{hero.name.split(' · ')[0]}</strong></div><ArrowUpLeft size={17} /></div>
            <div className="hero-art-bottom"><span>FORM / FUNCTION</span><span>MADE TO MOVE</span></div>
            <div className="hero-number">{hero.model?.replace('AF-', '') || '013'}</div>
          </div>
          <div className="hero-orbit-label">A DIFFERENT KIND OF EVERYDAY</div>
        </div>
        <a className="hero-scroll" href="#arrivals"><MoveDown size={15} /><span>کمی پایین‌تر</span></a>
      </section>

      <div className="ticker-band"><div className="ticker-track"><span>MOVE IN YOUR OWN FORM</span><i>✳</i><span>MADE FOR EVERYDAY</span><i>✳</i><span>MOVE IN YOUR OWN FORM</span><i>✳</i><span>MADE FOR EVERYDAY</span><i>✳</i></div></div>

      <section className="section arrivals-section reveal-on-scroll" id="arrivals">
        <div className="section-heading">
          <div><span className="eyebrow">THE LATEST / 01</span><h2>تازه‌رسیده‌ها</h2></div>
          <a className="text-link" href="#/shop">همه محصولات <ArrowUpLeft size={17} /></a>
        </div>
        <div className="arrivals-grid">
          {arrivals.map((product, index) => <ProductCard key={product.id} product={product} variant={`arrival-card arrival-${index + 1}`} />)}
          <div className="arrivals-aside"><span className="aside-index">AF / DROP 01</span><p>برای روزهای<br /><b>معمولیِ خاص.</b></p><span className="aside-mark">AF.</span><a href="#/shop">کشف مجموعه <ArrowUpLeft size={15} /></a></div>
        </div>
      </section>

      <section className="categories-section reveal-on-scroll">
        <div className="section-heading categories-heading">
          <div><span className="eyebrow">FIND YOUR FORM / 02</span><h2>از سر تا جزئیات</h2></div>
          <p>یک انتخاب کوچک، یک حال‌وهوای تازه.</p>
        </div>
        <div className="categories-grid">
          {categoryInfo.map((category, index) => {
            const product = getCategoryProduct(category.id)
            return product ? <a key={category.id} href={`#/shop?category=${category.id}`} className={`category-tile category-${index + 1}`}>
              <img src={asset(product.image)} alt={product.alt} loading="lazy" />
              <div className="category-tile-shade" />
              <div className="category-tile-top"><span>0{index + 1}</span><span>{category.sub}</span></div>
              <div className="category-tile-bottom"><strong>{category.title}</strong><i><ArrowUpLeft size={18} /></i></div>
            </a> : null
          })}
        </div>
      </section>

      <section className="campaign-section reveal-on-scroll">
        <div className="campaign-image-main"><img src={asset(campaign.image)} alt={campaign.alt} loading="lazy" /><span className="campaign-image-label">A STUDY IN EVERYDAY / {campaign.model?.replace('AF-', '') || '022'}</span></div>
        <div className="campaign-copy">
          <span className="eyebrow">A LITTLE MORE PERSONAL / 03</span>
          <span className="campaign-cross">✳</span>
          <h2>کمتر،<br /><span>اما درست.</span></h2>
          <p>قطعه‌هایی که قرار نیست فقط دیده شوند؛ قرار است زندگی شوند.</p>
          <a href={`#/product/${campaign.id}`} className="campaign-link">دیدن این انتخاب <ArrowUpLeft size={17} /></a>
          <div className="campaign-index">AFTERFORM<br /><b>{campaign.model?.replace('AF-', '') || '022'}</b></div>
        </div>
        <a className="campaign-image-small" href={`#/product/${featured.id}`}><img src={asset(featured.image)} alt={featured.alt} loading="lazy" /><span>ONE OF OUR OBJECTS <ArrowUpLeft size={15} /></span></a>
      </section>

      <section className="brand-intro reveal-on-scroll">
        <div className="brand-intro-left"><span className="eyebrow">THE LABEL / 04</span><div className="brand-orbit"><span>AF</span><i /><i /><i /></div></div>
        <div className="brand-intro-right"><h2>سبک تو،<br /><span>قانون تو.</span></h2><p>AFTERFORM برای پوشیدنی‌ها و چیزهای کوچکی‌ست که هر روز با ما حرکت می‌کنند.</p><a href="#/shop">بیشتر کشف کن <ArrowUpLeft size={17} /></a></div>
        <span className="brand-intro-coord">INDEPENDENT / EST. 2026</span>
      </section>

      <section className="newsletter-section reveal-on-scroll">
        <div className="newsletter-mark">A<span>F</span></div>
        <div className="newsletter-copy"><span className="eyebrow">A NOTE FROM US / 05</span><h2>خبرهای خوب،<br /><em>گاهی.</em></h2><p>برای خبرِ مجموعه‌های تازه.</p></div>
        <form className="newsletter-form" onSubmit={submitNewsletter}>
          {!newsletterDone ? <><label htmlFor="newsletter-email">ایمیل</label><div className="newsletter-input-wrap"><input id="newsletter-email" type="email" required value={email} onChange={(event) => setEmail(event.target.value)} placeholder="name@example.com" /><button type="submit" aria-label="ثبت ایمیل"><Send size={17} /></button></div><span className="newsletter-privacy">کم‌تعداد و به‌موقع.</span></> : <div className="newsletter-success"><b>✓</b><strong>به جمع ما خوش آمدی.</strong><span>ایمیلت ثبت شد.</span></div>}
        </form>
      </section>
    </main>
  )
}
