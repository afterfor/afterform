import { useState } from 'react'
import { ArrowLeft, Check, LockKeyhole, PackageCheck } from 'lucide-react'
import { useStore } from '../context/StoreContext'
import { asset, formatPrice, navigate } from '../utils/format'

export default function CheckoutPage() {
  const { cartItems, subtotal, shipping, total, clearCart } = useStore()
  const [form, setForm] = useState({ name: '', phone: '', address: '', notes: '' })
  const [errors, setErrors] = useState({})
  const [order, setOrder] = useState(null)
  const [submitting, setSubmitting] = useState(false)

  const setField = (key, value) => {
    setForm((current) => ({ ...current, [key]: value }))
    setErrors((current) => ({ ...current, [key]: '' }))
  }

  const submit = (event) => {
    event.preventDefault()
    const next = {}
    if (form.name.trim().length < 3) next.name = 'نام و نام خانوادگی را کامل وارد کن.'
    const phone = form.phone.replace(/[\s-]/g, '').replace(/[۰-۹]/g, (digit) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(digit))).replace(/[٠-٩]/g, (digit) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(digit)))
    if (!/^(09\d{9}|\+989\d{9})$/.test(phone)) next.phone = 'شماره موبایل باید با ۰۹ شروع شود و ۱۱ رقم داشته باشد.'
    if (form.address.trim().length < 15) next.address = 'آدرس دقیق‌تر وارد کن (حداقل ۱۵ نویسه).'
    setErrors(next)
    if (Object.keys(next).length) return
    setSubmitting(true)
    const saved = { id: `AF-${Math.floor(100000 + Math.random() * 899999)}`, name: form.name.trim(), phone, address: form.address.trim(), notes: form.notes.trim(), items: [...cartItems], subtotal, shipping, total, createdAt: new Date().toLocaleDateString('fa-IR') }
    setTimeout(() => {
      setOrder(saved)
      clearCart()
      setSubmitting(false)
    }, 420)
  }

  if (order) return <main className="checkout-page"><div className="order-success"><div className="success-orbit"><span><Check size={36} /></span></div><span className="eyebrow">AFTERFORM / ORDER CONFIRMED</span><h1>ثبت نمایشی<br /><em>موفق بود.</em></h1><p>ممنون {order.name}؛ سفارش آزمایشی تو ثبت شد.</p><div className="order-number"><span>شماره سفارش نمایشی</span><strong>{order.id}</strong><small>{order.createdAt}</small></div><div className="order-success-note"><PackageCheck size={19} /><span>این یک فروشگاه دمو است. سفارش ذخیره یا ارسال واقعی نمی‌شود و هیچ پرداختی انجام نشده است.</span></div><button className="button button-blue" onClick={() => navigate('/')}>بازگشت به AFTERFORM <ArrowLeft size={17} /></button></div></main>
  if (!cartItems.length) return <main className="checkout-page"><div className="checkout-empty"><span className="eyebrow">CHECKOUT / 00</span><h1>سبد خرید خالی است.</h1><p>برای شروع ثبت سفارش، ابتدا محصولی انتخاب کن.</p><button className="button button-blue" onClick={() => navigate('/shop')}>رفتن به فروشگاه <ArrowLeft size={17} /></button></div></main>

  return (
    <main className="checkout-page"><div className="page-title-band checkout-title"><span className="eyebrow">AFTERFORM / CHECKOUT</span><h1>ثبت سفارش<span>.</span></h1><p>جزئیات تحویل را وارد کن تا سفارش نمایشی ساخته شود.</p></div>
      <div className="checkout-layout"><form className="checkout-form" onSubmit={submit} noValidate><div className="checkout-step-head"><span>01</span><div><h2>اطلاعات تحویل</h2><p>اطلاعات تماس و نشانی مقصد</p></div></div>
          <div className="form-grid"><label className="form-field field-wide"><span>نام و نام خانوادگی <i>*</i></span><input value={form.name} onChange={(event) => setField('name',event.target.value)} placeholder="نام کامل" autoComplete="name" aria-invalid={Boolean(errors.name)} />{errors.name && <small>{errors.name}</small>}</label><label className="form-field"><span>شماره موبایل <i>*</i></span><input dir="ltr" inputMode="tel" value={form.phone} onChange={(event) => setField('phone',event.target.value)} placeholder="09xxxxxxxxx" autoComplete="tel" aria-invalid={Boolean(errors.phone)} />{errors.phone && <small>{errors.phone}</small>}</label><label className="form-field field-wide"><span>آدرس کامل <i>*</i></span><textarea rows="4" value={form.address} onChange={(event) => setField('address',event.target.value)} placeholder="استان، شهر، خیابان، کوچه، پلاک و واحد" autoComplete="street-address" aria-invalid={Boolean(errors.address)} />{errors.address && <small>{errors.address}</small>}</label><label className="form-field field-wide"><span>توضیحات تکمیلی <em>اختیاری</em></span><textarea rows="3" value={form.notes} onChange={(event) => setField('notes',event.target.value)} placeholder="توضیحات لازم برای تحویل سفارش" /></label></div>
          <div className="checkout-disclaimer"><LockKeyhole size={17} /><span>اطلاعات این فرم فقط برای نمایش تجربه ثبت سفارش استفاده می‌شود؛ پرداختی در کار نیست.</span></div>
          <button className="button button-blue button-full checkout-submit" type="submit" disabled={submitting}>{submitting ? 'در حال ثبت...' : 'تأیید و ثبت سفارش نمایشی'} <ArrowLeft size={17} /></button>
        </form>
        <aside className="checkout-summary"><div className="checkout-summary-title"><span className="eyebrow">YOUR SELECTION / 01</span><h2>خلاصه سفارش</h2></div><div className="checkout-items">{cartItems.map((item) => <div className="checkout-item" key={`${item.productId}-${item.size}-${item.color.id}`}><div className="checkout-item-image"><img src={asset(item.product.image)} alt={item.product.alt} /><b>{item.quantity}</b></div><div className="checkout-item-name"><strong>{item.product.name.split(' · ')[0]}</strong><span>{item.size} / {item.color.label}</span></div><strong className="checkout-item-price">{formatPrice(item.product.price*item.quantity)}</strong></div>)}</div><div className="checkout-totals"><div><span>جمع جزء</span><b>{formatPrice(subtotal)}</b></div><div><span>ارسال</span><b>{shipping ? formatPrice(shipping) : 'رایگان'}</b></div><div className="checkout-grand-total"><span>مبلغ نهایی</span><strong>{formatPrice(total)}</strong></div></div><div className="checkout-demo-mark"><span>DEMO STORE</span><b>NO PAYMENT / NO REAL ORDER</b></div></aside>
      </div>
    </main>
  )
}
